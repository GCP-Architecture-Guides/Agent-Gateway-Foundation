"""Telemetry utilities for the Agent Gateway.

Provides the after_model_callback that emits structured JSON token usage events.
These events are consumed by the log-based metrics in the Agent Observability
dashboard (modules/agent_observability) to power token usage widgets and alerts.

Without this callback wired into every agent, the dashboard shows zero usage
for the entire agent lifetime — there is no other signal source.
"""

import json
import logging
from typing import Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_response import LlmResponse

logger = logging.getLogger(__name__)


def emit_llm_usage_from_response(
    callback_context: CallbackContext,
    llm_response: LlmResponse,
) -> Optional[LlmResponse]:
    """ADK after_model_callback that emits a structured JSON usage event.

    Attach to any ADK Agent as after_model_callback=emit_llm_usage_from_response
    (or use GatewayAgent which wires this automatically).

    Emits a structured log line consumed by the Agent Gateway Observability
    dashboard log-based metrics:
        {"event": "llm_usage", "agent": "...", "model": "...",
         "input_tokens": 100, "output_tokens": 50, "total_tokens": 150}

    Returns:
        None — does not modify the LLM response.
    """
    try:
        usage = llm_response.usage_metadata
        if usage is None:
            return None

        event = {
            "event":         "llm_usage",
            "agent":         callback_context.agent_name,
            "model":         getattr(llm_response, "model_version", "unknown"),
            "input_tokens":  getattr(usage, "prompt_token_count",     0),
            "output_tokens": getattr(usage, "candidates_token_count", 0),
            "total_tokens":  getattr(usage, "total_token_count",      0),
        }
        logger.info(json.dumps(event))
    except Exception as exc:
        logger.warning("emit_llm_usage_from_response failed: %s", exc)

    return None
