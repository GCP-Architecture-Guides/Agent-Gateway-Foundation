"""GatewayAgent SDK — Agent Gateway compliance wrapper for ADK agents.

Exports:
    GatewayAgent: Drop-in replacement for ADK Agent that enforces:
        - GlobalGemini global-endpoint routing (Gemini 2.5/3.x compatibility)
        - OTEL token telemetry via after_model_callback
        - Synchronous query() method for :query REST endpoint support
        - get_project_id monkey-patch for Org Policy bypass
"""

from .agent import GatewayAgent
from .global_gemini import GlobalGemini
from .telemetry import emit_llm_usage_from_response

__all__ = ["GatewayAgent", "GlobalGemini", "emit_llm_usage_from_response"]
