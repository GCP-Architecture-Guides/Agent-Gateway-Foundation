"""GlobalGemini: Route Gemini 2.5/3.x model calls through the Vertex AI global endpoint.

Gemini 2.5/3.x models are only available via the global endpoint
(aiplatform.googleapis.com with location="global"). Regional endpoints
(e.g. us-east1-aiplatform.googleapis.com) return 404 / model-not-found.

The standard Gemini class picks up the region from the environment and defaults
to a regional endpoint when the Reasoning Engine is deployed regionally.
GlobalGemini overrides that by explicitly constructing a genai.Client pointing
at the global endpoint.
"""

import os
from google import genai
from google.adk.models.google_llm import Gemini


class GlobalGemini(Gemini):
    """Drop-in replacement for Gemini() that always uses the global endpoint.

    Usage:
        from gateway_agent import GlobalGemini
        model = GlobalGemini("gemini-2.5-flash")

    When a model becomes available at the regional endpoint, remove this wrapper
    and use Gemini() directly with the regional client.
    """

    def _get_client_args(self):
        project = (
            os.environ.get("GCP_PROJECT_ID")
            or os.environ.get("GOOGLE_CLOUD_PROJECT")
        )
        client = genai.Client(
            vertexai=True,
            project=project,
            location="global",   # ← only difference from the default Gemini class
        )
        return {"api_client": client}
